let result = 0;
function addUpTo(n) {
  for (let i = 1; i <= n; i++) {
    result += i;
  }

  return result;
}
console.log(addUpTo(10000));
